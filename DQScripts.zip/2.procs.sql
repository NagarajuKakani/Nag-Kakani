DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_data_dic_tbl_proc`(table_name varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL) RETURNS void AS
DECLARE
ERR_MSG text = "";
PROC_NAME text = 'dq_data_dic_tbl_proc';

DYN_QUERY text;

BEGIN

DYN_QUERY=CONCAT(' DELETE FROM dq_data_dictonary_tbl WHERE table_name=REPLACE("',table_name,'",''_stg_'',''_raw_'')       ');

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT('insert into dq_data_dictonary_tbl
(table_name,column_name,column_index,data_type,length_precision,scale,max_value_length,condition_no)

SELECT table_name,column_name,ORDINAL_POSITION,datatype,numeric_precision,numeric_scale,character_maximum_length,
CASE
WHEN datatype IN (''date'',''datetime'',''timestamp(6)'',''datetime(6)'',''now(6)'') THEN ''1,3''
WHEN datatype IN (''decimal'') THEN ''1,2''
ELSE ''1''
END

FROM
(
SELECT REPLACE(table_name,''_stg_'',''_raw_'') table_name,column_name,ORDINAL_POSITION,
CASE WHEN COLUMN_TYPE IN (\'datetime(6)\',\'timestamp(6)\',\'now(6)\') THEN COLUMN_TYPE ELSE data_type END datatype,
numeric_precision,numeric_scale,character_maximum_length

FROM information_schema.columns
WHERE table_name="',table_name,'"
) X

');

#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(DYN_QUERY);

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY= ' UPDATE dq_data_dictonary_tbl SET FORMAT=''YYYY-MM-DD'' and condition_no=''1,3'' WHERE data_type=''date'' ';

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY= ' UPDATE dq_data_dictonary_tbl SET FORMAT=''HH24:MI:SS'' and condition_no=''1'' WHERE data_type=''time'' ';

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY= ' UPDATE dq_data_dictonary_tbl SET FORMAT=''YYYY-MM-DD HH24:MI:SS'' and condition_no=''1,3'' WHERE data_type=''datetime'' ';

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY= ' UPDATE dq_data_dictonary_tbl SET FORMAT=''YYYY-MM-DD HH24:MI:SS:FFFFFF'' and condition_no=''1,3''
WHERE data_type in (''timestamp(6)'',''datetime(6)'',''now(6)'') ';

EXECUTE IMMEDIATE DYN_QUERY;

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();

RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_value_mapping_proc`(tablename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'dq_value_mapping_proc';

raw_data_string text;

cur_prep_tbl_name varchar(50);
cur_tbl_name varchar(50);
cur_col_name varchar(50);
cur_col_cat int(1);
catcol_list varchar(2000)='';
catcolumn_list varchar(2000)='';
noncatcol_list varchar(2000)='';

data_dic_query1 QUERY
(
table_name varchar(255),
column_name varchar(255),
category_col_indi int(1)
);

data_dic_query ARRAY(
RECORD(
table_name varchar(255),
column_name varchar(255),
category_col_indi int(1)
));


begin

cur_tbl_name=replace(tablename,'_stg_','_raw_');

raw_data_string =CONCAT('
select table_name,column_name,category_col_indi
from dq_data_dictonary_tbl
where lower(trim(replace(replace(table_name,''`'',''''),''_'','''')))  =  lower(trim(replace(replace("',cur_tbl_name,'",''`'',''''),''_'','''')))
');

raw_data_string = CONCAT(raw_data_string,'
and column_name not in (''diwo_offset'',''diwo_data_source_offset'',''diwo_data_source_name'',''diwo_process_dt'',''ins_ts'',''upd_ts'')
');

data_dic_query1 = TO_QUERY(raw_data_string);
data_dic_query = COLLECT(data_dic_query1);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(raw_data_string);

FOR columns IN data_dic_query
LOOP

cur_col_name=columns.column_name;
cur_col_cat=columns.category_col_indi;

IF cur_col_cat=1
THEN
raw_data_string=CONCAT(' delete from dq_value_mapping_tbl where table_name="',tablename,'" and column_name="',cur_col_name,'" ');

EXECUTE IMMEDIATE raw_data_string;

raw_data_string=CONCAT(' insert into dq_value_mapping_tbl (table_name,column_name,actual_value,transform_value)
select distinct "',tablename,'","',cur_col_name,'",',cur_col_name,',title_case(nvl(',cur_col_name,',""))  from ',tablename,' ');

#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(raw_data_string);
EXECUTE IMMEDIATE raw_data_string;

catcol_list=CONCAT(catcol_list,' ',cur_col_name,',');
catcolumn_list=CONCAT(catcolumn_list,' title_case(',cur_col_name,'),');

ELSE

noncatcol_list=CONCAT(noncatcol_list,' ',cur_col_name,',');
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(catcolumn_list);

END IF;

END LOOP;

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();


RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_master_column_level_metrics`(filename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, tablename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'dq_master_column_level_metrics';

DYN_QUERY TEXT;

data_dic_query1 QUERY
(
table_name varchar(255),
column_name varchar(255),
condition_no varchar(255)
);

data_dic_query ARRAY(
RECORD(
table_name varchar(255),
column_name varchar(255),
condition_no varchar(255)
));

begin
insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,'FILE','Started',NULL);


DYN_QUERY =CONCAT('
select table_name,column_name,condition_no
from dq_data_dictonary_tbl
where table_name="',tablename,'"
and column_name not in (''diwo_data_source_offset'',''diwo_data_source_name'',''diwo_process_dt'',''ins_ts'',''upd_ts'')
order by column_index asc
');

data_dic_query1 = TO_QUERY(DYN_QUERY);
data_dic_query = COLLECT(data_dic_query1);

FOR columns IN data_dic_query
LOOP

CALL dq_column_level_metrics(filename,columns.table_name,columns.column_name,columns.condition_no);

END LOOP;

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,'FILE','Finished',NULL);

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,'FILE','Error',ERR_MSG);

RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_column_level_metrics`(filename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, tablename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, columnname varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, condition_no varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS

declare

ERR_MSG text = "";
PROC_NAME text = 'dq_column_level_metrics';
DYN_QUERY TEXT;

cur_condition varchar(25);

condition_query1 QUERY
(
condition_no int(5),
condition_query varchar(2000),
condition_query_insert varchar(2000)
);

condition_query ARRAY(
RECORD(
condition_no int(5),
condition_query varchar(2000),
condition_query_insert varchar(2000)
));

begin

DYN_QUERY = CONCAT('select condition_no,condition_query,condition_query_insert
from dq_conditions_tbl where condition_no in (',condition_no,')
');

condition_query1 = TO_QUERY(DYN_QUERY);
condition_query = COLLECT(condition_query1);

FOR RULES IN condition_query
LOOP

cur_condition=RULES.condition_no;

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,columnname,cur_condition,'Started',NULL);

DYN_QUERY=CONCAT(RULES.condition_query_insert,' SELECT  "',tablename,'","',columnname,'",',RULES.condition_query,' ');
DYN_QUERY=REPLACE(REPLACE(DYN_QUERY,'TABLE',tablename),'COLUMN',columnname);
DYN_QUERY=CONCAT(DYN_QUERY,' WHERE UPPER(diwo_data_source_name)=UPPER("',filename,'")   ');

EXECUTE IMMEDIATE DYN_QUERY;

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,columnname,cur_condition,'Finished',NULL);


END LOOP;

DYN_QUERY=CONCAT(' delete from dq_metrics_tbl where table_name="',tablename,'" and column_name="',columnname,'" and diwo_data_source_name="',filename,'"  ');

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(' insert into dq_metrics_tbl
(
diwo_data_source_name,table_name,column_name,
records_count, distinct_count, notnull_count, null_count, unknown_count, notknown_count, na_count, blank_count, valid_count,invalid_count,zero_count,empty_count,min_value,max_value,avg_value,sum_value,min_date,max_date,out_range_status
)
select
"',filename,'",table_name,column_name,
sum(nvl(records_count,0)) records_count,
sum(nvl(distinct_count,0)) distinct_count,
sum(nvl(notnull_count,0)) notnull_count,
sum(nvl(null_count,0)) null_count,
sum(nvl(unknown_count,0)) unknown_count,
sum(nvl(notknown_count,0)) notknown_count,
sum(nvl(na_count,0)) na_count,
sum(nvl(blank_count,0)) blank_count,
sum(nvl(valid_count,0)) valid_count,
sum(nvl(invalid_count,0)) invalid_count,
sum(nvl(zero_count,0)) zero_count,
sum(nvl(empty_count,0)) empty_count,
sum(nvl(min_value,0)) min_value,
sum(nvl(max_value,0)) max_value,
sum(nvl(avg_value,0)) avg_value,
sum(nvl(sum_value,0)) sum_value,
MIN(min_date) min_date,
MAX(max_date) max_date,
sum(nvl(out_range_status,0)) out_range_status

from dq_dummy_metrics_tbl
group by table_name,column_name

');

EXECUTE IMMEDIATE DYN_QUERY;

delete from dq_dummy_metrics_tbl;

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,columnname,cur_condition,'Error',ERR_MSG);

RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_master_column_level_proc`(filename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, tablename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'dq_master_column_level_proc';

data_dic_string TEXT;
condition_string TEXT;
raw_data_string TEXT;
current_file varchar(200)='FILE';
cur_tbl_name varchar(50);
cur_col_name varchar(50);

data_dic_query1 QUERY
(
table_name varchar(255),
column_name varchar(255)
);

data_dic_query ARRAY(
RECORD(
table_name varchar(255),
column_name varchar(255)
));

begin

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,'FILE','Started',NULL);


data_dic_string =CONCAT('
select table_name,column_name
from dq_data_dictonary_tbl
where table_name="',tablename,'"
and column_name not in (''diwo_data_source_offset'',''diwo_data_source_name'',''diwo_process_dt'',''ins_ts'',''upd_ts'')
order by column_index asc
');

data_dic_query1 = TO_QUERY(data_dic_string);
data_dic_query = COLLECT(data_dic_query1);

FOR columns IN data_dic_query
LOOP

cur_tbl_name=columns.table_name;
cur_col_name=columns.column_name;
current_file=filename;

CALL dq_column_level_proc(current_file,cur_tbl_name,cur_col_name);

END LOOP;

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`status`,`status_msg`)
values
('SQL_dq',filename,tablename,'FILE','Finished',NULL);

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();


RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE PROCEDURE `dq_column_level_proc`(filename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, tablename varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, columnname varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'dq_column_level_proc';

data_dic_string TEXT;
condition_string TEXT;
raw_data_string TEXT;
current_file varchar(200)='FILE';

cur_tbl_name varchar(50);
cur_col_name varchar(50);
cur_datatype_name varchar(50);
cur_length_precision varchar(50);
cur_scale varchar(50);
cur_format varchar(50);
cur_valid_values varchar(50);
cur_min_range varchar(50);
cur_max_range varchar(50);
cur_condition_no varchar(50);
convert_type varchar(50);

data_dic_query1 QUERY
(
table_name varchar(255),
column_name varchar(255),
data_type varchar(255),
length_precision int(5),
scale int(5),
format varchar(255),
valid_values varchar(50),
min_range varchar(50),
max_range varchar(50),
condition_no varchar(50)

);

data_dic_query ARRAY(
RECORD(
table_name varchar(255),
column_name varchar(255),
data_type varchar(255),
length_precision int(5),
scale int(5),
format varchar(255),
valid_values varchar(50),
min_range varchar(50),
max_range varchar(50),
condition_no varchar(50)
));

condition_query1 QUERY
(
condition_no int(5),
condition_query varchar(2000),
condition_query_insert varchar(2000)
);

condition_query ARRAY(
RECORD(
condition_no int(5),
condition_query varchar(2000),
condition_query_insert varchar(2000)
));

begin


data_dic_string =CONCAT('
select table_name,column_name,data_type,length_precision,scale,upper(format) format,valid_values,min_range,max_range,condition_no
from dq_data_dictonary_tbl
where table_name="',tablename,'" and column_name="',columnname,'"
and column_name not in (''diwo_data_source_offset'',''diwo_data_source_name'',''diwo_process_dt'',''ins_ts'',''upd_ts'')
and data_type not in (''timestamp'')
order by column_index asc
');

data_dic_query1 = TO_QUERY(data_dic_string);
data_dic_query = COLLECT(data_dic_query1);

FOR columns IN data_dic_query
LOOP

cur_tbl_name=columns.table_name;
cur_col_name=columns.column_name;
cur_datatype_name=columns.data_type;
cur_length_precision=columns.length_precision;
cur_scale=columns.scale;
cur_format=columns.format;
cur_valid_values=columns.valid_values;
cur_min_range=columns.min_range;
cur_max_range=columns.max_range;
cur_condition_no=columns.condition_no;
current_file=filename;

condition_string = CONCAT('
select condition_no,condition_query,condition_query_insert
from dq_conditions_tbl
where condition_no in (',cur_condition_no,')
');

condition_query1 = TO_QUERY(condition_string);
condition_query = COLLECT(condition_query1);

FOR RULES IN condition_query
LOOP

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',current_file,cur_tbl_name,cur_col_name,RULES.condition_no,'Started',NULL);


raw_data_string=CONCAT(RULES.condition_query_insert,' SELECT  "',cur_tbl_name,'","',cur_col_name,'",',RULES.condition_query,' ');
raw_data_string=REPLACE(REPLACE(raw_data_string,'TABLE',cur_tbl_name),'COLUMN',cur_col_name);

IF lower(cur_datatype_name) NOT IN ('date','timestamp')
THEN

IF cur_valid_values IS NOT NULL
THEN raw_data_string=REPLACE(raw_data_string,'(,)',CONCAT('(',cur_valid_values,')'));
END IF;

IF cur_min_range IS NOT NULL AND cur_max_range IS NOT NULL
THEN
raw_data_string=REPLACE(raw_data_string,'min_range',CONCAT('"',cur_min_range,'"'));
raw_data_string=REPLACE(raw_data_string,'max_range',CONCAT('"',cur_max_range,'"'));
END IF;

END IF;

raw_data_string=CONCAT(raw_data_string,' WHERE UPPER(diwo_data_source_name)=UPPER("',filename,'")   ');

EXECUTE IMMEDIATE raw_data_string;

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',current_file,cur_tbl_name,cur_col_name,RULES.condition_no,'Finished',NULL);

END LOOP;

raw_data_string=CONCAT(' delete from dq_metrics_tbl where table_name="',tablename,'" and diwo_data_source_name="',current_file,'"    ');

delete from dq_dummy_metrics_tbl;

EXECUTE IMMEDIATE raw_data_string;

raw_data_string=CONCAT(' insert into dq_metrics_tbl
(
diwo_data_source_name,table_name,column_name,
records_count, distinct_count, notnull_count, null_count, unknown_count, notknown_count, na_count, blank_count, valid_count,invalid_count,zero_count,empty_count,min_value,max_value,avg_value,sum_value,min_date,max_date,out_range_status
)
select
"',current_file,'",table_name,column_name,
sum(nvl(records_count,0)) records_count,
sum(nvl(distinct_count,0)) distinct_count,
sum(nvl(notnull_count,0)) notnull_count,
sum(nvl(null_count,0)) null_count,
sum(nvl(unknown_count,0)) unknown_count,
sum(nvl(notknown_count,0)) notknown_count,
sum(nvl(na_count,0)) na_count,
sum(nvl(blank_count,0)) blank_count,
sum(nvl(valid_count,0)) valid_count,
sum(nvl(invalid_count,0)) invalid_count,
sum(nvl(zero_count,0)) zero_count,
sum(nvl(empty_count,0)) empty_count,
sum(nvl(min_value,0)) min_value,
sum(nvl(max_value,0)) max_value,
sum(nvl(avg_value,0)) avg_value,
sum(nvl(sum_value,0)) sum_value,
MIN(min_date) min_date,
MAX(max_date) max_date,
sum(nvl(out_range_status,0)) out_range_status

from dq_dummy_metrics_tbl
group by table_name,column_name

');

EXECUTE IMMEDIATE raw_data_string;

delete from dq_dummy_metrics_tbl;

END LOOP;

EXCEPTION
WHEN OTHERS THEN

ERR_MSG=exception_message();

insert into dq_metrics_log_tbl
(task_type,`diwo_data_source_name`,`table_name`,`column_name`,`condition_no`,`status`,`status_msg`)
values
('SQL_dq',current_file,cur_tbl_name,cur_col_name,cur_condition_no,'Error',ERR_MSG);

RAISE user_exception(ERR_MSG);

end //
DELIMITER ;

####

DELIMITER //
CREATE OR REPLACE FUNCTION `title_case`(param_value text CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS text CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS
DECLARE
err_msg text='';
cur_param_value text;
pos_char varchar(1);
upp_pos_char varchar(1);

BEGIN
cur_param_value=CONCAT(' ',lower(param_value));
FOR X IN 1..length(param_value)-1
LOOP

pos_char=SUBSTR(cur_param_value,X,1);

        IF pos_char IN (' ',',', '.', '_', '-', '/', '&','+')
        THEN

        upp_pos_char=UPPER(SUBSTR(cur_param_value,X+1,1));
        cur_param_value=CONCAT(SUBSTR(cur_param_value,1,X),upp_pos_char,SUBSTR(cur_param_value,X+2));

        END IF;

END LOOP;

RETURN REPLACE(SUBSTR(cur_param_value,2),' And ',' and ');

EXCEPTION
WHEN OTHERS THEN

err_msg=exception_message();

RAISE user_exception(err_msg);

end //
DELIMITER ;
