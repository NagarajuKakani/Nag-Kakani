CREATE TABLE `dq_conditions_tbl` (
  `condition_no` int(5) DEFAULT NULL,
  `condition_descr` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `condition_query` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `condition_query_insert` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `cond_IDX` (`condition_no`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */ 
;

 CREATE TABLE `dq_data_dictonary_tbl` (
  `diwo_data_source_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `table_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_index` int(5) DEFAULT NULL,
  `column_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `data_type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `length_precision` int(5) DEFAULT NULL,
  `scale` int(5) DEFAULT NULL,
  `format` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `min_range` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `max_range` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `valid_values` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `min_value_length` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `max_value_length` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `condition_no` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '1',
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `ORD_IDX` (`column_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `dq_date_metrics_tbl` (
  `table_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `records_count` int(20) DEFAULT NULL,
  `distinct_count` int(20) DEFAULT NULL,
  `notnull_count` int(20) DEFAULT NULL,
  `null_count` int(20) DEFAULT NULL,
  `empty_count` int(20) DEFAULT NULL,
  `min_value` decimal(18,2) DEFAULT NULL,
  `max_value` decimal(18,2) DEFAULT NULL,
  `out_of_range_count` int(20) DEFAULT NULL,
  `file_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `data_IDX` (`table_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */ 
;

CREATE TABLE `dq_metrics_log_tbl` (
  `diwo_data_source_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `table_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `condition_no` int(20) DEFAULT NULL,
  `task_type` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status_msg` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `data_IDX` (`table_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */ 
;

CREATE TABLE `dq_metrics_tbl` (
  `diwo_data_source_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `table_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `records_count` int(20) DEFAULT NULL,
  `distinct_count` int(20) DEFAULT NULL,
  `notnull_count` int(20) DEFAULT NULL,
  `null_count` int(20) DEFAULT NULL,
  `unknown_count` int(20) DEFAULT NULL,
  `notknown_count` int(20) DEFAULT NULL,
  `na_count` int(20) DEFAULT NULL,
  `blank_count` int(20) DEFAULT NULL,
  `zero_count` int(20) DEFAULT NULL,
  `empty_count` int(20) DEFAULT NULL,
  `min_value` decimal(18,2) DEFAULT NULL,
  `max_value` decimal(18,2) DEFAULT NULL,
  `avg_value` decimal(18,2) DEFAULT NULL,
  `sum_value` decimal(18,2) DEFAULT NULL,
  `valid_count` int(20) DEFAULT NULL,
  `invalid_count` int(20) DEFAULT NULL,
  `min_date` datetime(6) DEFAULT NULL,
  `max_date` datetime(6) DEFAULT NULL,
  `out_range_status` int(5) DEFAULT NULL,
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `data_IDX` (`table_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `dq_dummy_metrics_tbl` (
  `diwo_data_source_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `table_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `records_count` int(20) DEFAULT NULL,
  `distinct_count` int(20) DEFAULT NULL,
  `notnull_count` int(20) DEFAULT NULL,
  `null_count` int(20) DEFAULT NULL,
  `unknown_count` int(20) DEFAULT NULL,
  `notknown_count` int(20) DEFAULT NULL,
  `na_count` int(20) DEFAULT NULL,
  `blank_count` int(20) DEFAULT NULL,
  `zero_count` int(20) DEFAULT NULL,
  `empty_count` int(20) DEFAULT NULL,
  `min_value` decimal(18,2) DEFAULT NULL,
  `max_value` decimal(18,2) DEFAULT NULL,
  `avg_value` decimal(18,2) DEFAULT NULL,
  `sum_value` decimal(18,2) DEFAULT NULL,
  `valid_count` int(20) DEFAULT NULL,
  `invalid_count` int(20) DEFAULT NULL,
  `min_date` datetime(6) DEFAULT NULL,
  `max_date` datetime(6) DEFAULT NULL,
  `out_range_status` int(5) DEFAULT NULL,
  `ins_ts` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `upd_ts` datetime(6) DEFAULT null ON UPDATE CURRENT_TIMESTAMP(6),
  KEY `data_IDX` (`table_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `dq_value_mapping_tbl` (
  `table_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `actual_value` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `transform_value` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `upd_ts` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY `ORD_IDX` (`column_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=CREATE, AUTOSTATS_SAMPLING=ON */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */ 
;

CREATE TABLE `dq_type_level_log_tbl` (
  `table_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `column_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  KEY `ORD_IDX` (`table_name`) /*!90619 USING CLUSTERED COLUMNSTORE */
  /*!90618 , SHARD KEY () */ 
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=OFF, AUTOSTATS_SAMPLING=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

INSERT INTO `dq_conditions_tbl` (`condition_no`,`condition_descr`,`condition_query`,`condition_query_insert`) VALUES (1,'Count of Total records,distinct records,Not Null,Null,Unknown,Notknown,N/A,Blank,Zero','\nCOUNT(*) RECORDS_COUNT,\nCOUNT(DISTINCT COLUMN) DISTINCT_COUNT,\nCOUNT(COLUMN) AS NOTNULL_COUNT,\nSUM(CASE WHEN COLUMN IS NULL THEN 1 ELSE 0 END) NULL_COUNT,\nSUM(CASE WHEN UPPER(COLUMN)=\'UNKNOWN\' THEN 1 ELSE 0 END) UNKNOWN_COUNT,\nSUM(CASE WHEN UPPER(COLUMN)=\'NOT-KNOWN\' THEN 1 ELSE 0 END) NOTKNOWN_COUNT,\nSUM(CASE WHEN UPPER(COLUMN)=\'N/A\' THEN 1 ELSE 0 END) NA_COUNT,\nSUM(CASE WHEN UPPER(COLUMN)=\'BLANK\' THEN 1 ELSE 0 END) BLANK_COUNT,\nSUM(CASE WHEN COLUMN=0 THEN 1 ELSE 0 END) ZERO_COUNT\nFROM TABLE\n','\nINSERT INTO dq_dummy_metrics_tbl\n(\ntable_name,column_name,\nrecords_count,distinct_count,notnull_count,null_count,\nunknown_count,notknown_count,na_count,blank_count,zero_count\n)\n');
INSERT INTO `dq_conditions_tbl` (`condition_no`,`condition_descr`,`condition_query`,`condition_query_insert`) VALUES (3,'Count of values outside Specified range Min and Max','\nCOUNT(COLUMN) OUTRANGE_COUNT\nFROM TABLE\nWHERE COLUMN NOT BETWEEN min_range AND max_range\n','\nINSERT INTO dq_dummy_metrics_tbl\n(\ntable_name,column_name,\nout_of_range_count\n)\n');
INSERT INTO `dq_conditions_tbl` (`condition_no`,`condition_descr`,`condition_query`,`condition_query_insert`) VALUES (2,'Count of Valid,Inavlid Records','\n SUM(CASE WHEN COLUMN IN (,) THEN 1 ELSE 0 END) VALID_COUNT,\n SUM(CASE WHEN COLUMN NOT IN (,) THEN 1 ELSE 0 END) INVALID_COUNT\n FROM TABLE\n ','\nINSERT INTO dq_dummy_metrics_tbl\n(\ntable_name,column_name,\nvalid_count,invalid_count\n)\n');
