DELIMITER //
CREATE OR REPLACE PROCEDURE `cmm_tvf_po_rank_select`(name text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, select_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, metric text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, time_level text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, time_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, filter_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, group_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, having_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, rank_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, rank_order text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, limit_condition text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, hashkey text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, request_id text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL) RETURNS void AS
    DECLARE
           err_msg TEXT = '';
           proc_name TEXT = 'cmm_tvf_po_rank_select';
           base_tbl VARCHAR(255);
           metric_values VARCHAR(255);
  		   kp_flag  VARCHAR(500);
  		 
           str TEXT = '';
           ts datetime(6) = NOW(6);
           time_criteria TEXT = CONCAT(' AND TIME ',time_condition);
           select_criteria TEXT = '';
           select_column_list TEXT = '';
	       metric_column_list TEXT = '';
           new_cuboidid  TEXT = '';
           filter_criteria TEXT = IF(filter_condition <> '',CONCAT(' AND ',filter_condition),filter_condition);
           group_criteria TEXT = '';
           having_criteria TEXT = IF(having_condition <> '', CONCAT(' HAVING ',having_condition),having_condition);
           rank_criteria TEXT;
           select_cols TEXT = udf.createSelectString(select_condition,0);
    BEGIN    
      
  	    str = CONCAT(' SELECT metric_value,metric_columns FROM cs_metric_metadata_tbl where artifact_id=',quote(REPLACE(metric,'`','')),'  ');
     	 
       EXECUTE IMMEDIATE str into metric_values,metric_column_list;
     	 
       ########## Multi Cuboid Changes ##########
     	select replace(select_cols,CHAR(10),'') into select_cols;
		select_column_list=lower(replace(replace(select_cols,' ',''),'`',''));
        select_column_list=CONCAT('''',REPLACE(select_column_list,',',''','''),'''');
		
		metric_column_list=lower(replace(replace(metric_column_list,' ',''),'`',''));
        metric_column_list=CONCAT('''',REPLACE(metric_column_list,',',''','''),'''');
		  		
     	 str = CONCAT(' select 
		case when instr(kpi_flag,'','')=0  then kpi_flag when instr(kpi_flag,'','')!=0  then substr(kpi_flag,1,instr(kpi_flag,'','')-1) end kpi_flag
		from
		(
		select kpi_flag from cuboid_attr_mapping_tbl  where cub_tbl_column in (',select_column_list,') 
		union
		select kpi_flag from cuboid_facts_mapping_tbl where cub_tbl_column in (',metric_column_list,')
		) X order by length(kpi_flag) asc limit 1 ');

		
          EXECUTE IMMEDIATE str into kp_flag;
          
		  base_tbl=CONCAT('','cuboid_tbl_',kp_flag);
          new_cuboidid=return_cuboidid(kp_flag,lower(time_level),select_cols);
     	 	 	
          ##################	
      
      rank_criteria = CONCAT(', RANK() OVER (PARTITION BY ',rank_condition,' ORDER BY ', metric_values,' ',rank_order,' ) ');
      select_criteria = IF(select_condition <> '',CONCAT(select_criteria,',',select_condition),select_criteria);
      select_criteria = CONCAT(select_criteria,',',metric_values,' AS ',metric,' ',rank_criteria, ' AS Rank ');
      select_criteria = CONCAT('SELECT udf.custom_time_format("",TIME) AS time ',select_criteria);
      
      group_criteria = udf.replaceTimeCol(group_condition,time_level);
      group_criteria = IF(group_criteria <> '',CONCAT(' GROUP BY ',group_criteria),group_criteria);
   
      str = CONCAT(select_criteria,' FROM ',base_tbl,' WHERE CUBOIDID = ',QUOTE(new_cuboidid),time_criteria,
                      filter_criteria,group_criteria,having_criteria);
   
      str = CONCAT('SELECT * FROM ( ',str, ') A WHERE RANK <= ',limit_condition);
	  
	  #echo select str as q;
 	 
      EXECUTE IMMEDIATE CONCAT('ECHO ',str);
   
       end //
DELIMITER ;
