DELIMITER //
CREATE OR REPLACE FUNCTION `createSelectString`(columnStr text CHARACTER SET utf8 COLLATE utf8_general_ci NULL, id int(11) NULL DEFAULT 1) RETURNS text CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS
DECLARE
  str text;
  cols array(text) = split(columnStr,',');
  num_cols int = LENGTH(cols);
  col text;
  col_array array(text) = CREATE_ARRAY(2);
  select_cols array(text) = CREATE_ARRAY(num_cols);
BEGIN
  IF TRIM(columnStr) = "" OR num_cols = 0 THEN
    str = "";
  ELSE
    FOR i IN 0..num_cols-1 LOOP
      col_array = split(cols[i],'AS');
      str = TRIM(col_array[id]);
      IF id = 1 THEN
        str = CONCAT("X.",str);
      END IF;
      select_cols[i] = str;
    END LOOP;
    str = array_to_string(select_cols,',');
  END IF;
  RETURN str;
end //
DELIMITER ;
