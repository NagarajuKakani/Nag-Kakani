DELIMITER //
CREATE OR REPLACE FUNCTION `custom_time_format`(time_level text CHARACTER SET utf8 COLLATE utf8_general_ci NULL, time_value int(11) NULL) RETURNS bigint(20) NULL AS
DECLARE
  it bigint = CAST(CONCAT(time_value,'03') AS unsigned);
  day_formats JSON = '["year_month_day","year_day"]';
  week_formats JSON = '["year_week","year_month_week"]';
  month_formats JSON = '["year_month"]';
BEGIN
  it = UNIX_TIMESTAMP(DATE_FORMAT(it,'%Y%m%d'))*1000;
  RETURN it;
END //
DELIMITER ;
