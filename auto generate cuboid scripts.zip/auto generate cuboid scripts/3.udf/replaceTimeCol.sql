DELIMITER //
CREATE OR REPLACE FUNCTION `replaceTimeCol`(columnStr text CHARACTER SET utf8 COLLATE utf8_general_ci NULL, time_level text CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS text CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS
DECLARE
  str text;
  arr array(text) = SPLIT(columnStr,',');
  arr_len int = LENGTH(arr);
  arr2 array(text);
  tlevel text = LOWER(TRIM(time_level));
BEGIN
  IF arr_len > 0 THEN
    arr2 = CREATE_ARRAY(arr_len);
	FOR i IN 0 .. arr_len-1 LOOP
      str = LOWER(TRIM(arr[i]));
      IF str = tlevel THEN
        str = 'time';
      END IF;
      arr2[i] = str;
  END LOOP;
  ELSE arr2 = [""];
  END IF;
  str = array_to_string(arr2);
  RETURN str;
END //
DELIMITER ;
