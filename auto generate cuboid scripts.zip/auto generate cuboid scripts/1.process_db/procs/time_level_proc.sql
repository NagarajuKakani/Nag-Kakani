delimiter //
CREATE OR REPLACE PROCEDURE `time_level_proc`(first_or_last text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, run_date date NOT NULL, join_col text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, time_col text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, calendertblname text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'RS_STG_NRF_CAL_TBL') RETURNS varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS

declare
err_msg text = "";
proc_name text = 'time_level_proc';
rundate date = run_date;

from_range_dyn text;
from_range_qry query(time text);
from_range text;

from_range_time_dyn text;
from_range_time_qry query(a int);
from_range_time int;

to_range_dyn text;
to_range_qry query(time text);
to_range text;

to_range_time_dyn text;
to_range_time_qry query(b int);
to_range_time int;

range_time text;

BEGIN
IF first_or_last = 'F'
THEN
from_range_dyn = concat('select distinct ',time_col,' from ',calendertblname,' where trxn_dt = "',rundate,'" ');
from_range_qry = to_query(from_range_dyn);
from_range = scalar(from_range_qry);

from_range_time_dyn = concat('select min(',join_col,') as a from ',calendertblname,' where ',time_col,' = "',from_range,'" ');
from_range_time_qry = to_query(from_range_time_dyn);
range_time = scalar(from_range_time_qry);
#echo select range_time as frt;


ELSIF first_or_last = 'L'
THEN
to_range_dyn = concat('select distinct ',time_col,' from ',calendertblname,' where trxn_dt = "',rundate,'" ');
to_range_qry = to_query(to_range_dyn);
to_range = scalar(to_range_qry);


to_range_time_dyn = concat('select max(',join_col,') as b from ',calendertblname,' where ',time_col,' = "',to_range,'" ');
to_range_time_qry = to_query(to_range_time_dyn);
range_time = scalar(to_range_time_qry); 
#echo select range_time as trt;

END IF; 

 return range_time;

end //
delimiter ;