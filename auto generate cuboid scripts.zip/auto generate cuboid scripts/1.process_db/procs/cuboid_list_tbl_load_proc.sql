delimiter //
CREATE OR REPLACE PROCEDURE `cuboid_list_tbl_load_proc`(kpi_flag_lable varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, time_column varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, list_columns text CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
DECLARE
err_msg TEXT = '';
proc_name TEXT = 'cuboid_list_tbl_load_proc';
cuboid_list_tblname varchar(100)= CONCAT('cuboid_list_tbl_',kpi_flag_lable);

load_cuboidid varchar(500);
base_cuboidid varchar(500);
min_ord_id tinyint(5);
max_ord_id tinyint(5);
min_inv_id tinyint(5);
max_inv_id tinyint(5);

listcolumns text;
base_cub_columns  text; 
base_cuboidid_columns  text;
final_str text;
delete_str text; 

BEGIN

final_str=CONCAT('select nvl(min(inv_id),0),nvl(max(inv_id),0) from ',cuboid_list_tblname,' where time=',quote(time_column),'  ');

EXECUTE IMMEDIATE final_str into min_inv_id,max_inv_id;

final_str=CONCAT('select nvl(min(ord_id),0),nvl(max(ord_id),0) from ',cuboid_list_tblname,'  ');

EXECUTE IMMEDIATE final_str into min_ord_id,max_ord_id;


if min_ord_id=0 
THEN 

load_cuboidid=return_cuboidid(kpi_flag_lable,time_column,'base');
base_cuboidid='base';

final_str=CONCAT(' select group_concat(cub_tbl_column) from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' and dim_idx!=1');

execute immediate final_str into base_cub_columns;

base_cuboidid_columns=lower(replace(replace(base_cub_columns,' ',''),'`',''));
base_cuboidid_columns=CONCAT('''',REPLACE(base_cuboidid_columns,',',''','''),'''');

delete_str=CONCAT(' DELETE FROM ',cuboid_list_tblname,' WHERE load_cuboid=',quote(load_cuboidid),'   ');

EXECUTE IMMEDIATE delete_str;

final_str=CONCAT('select nvl(min(ord_id),0),nvl(max(ord_id),0) from ',cuboid_list_tblname,'  ');

EXECUTE IMMEDIATE final_str into min_ord_id,max_ord_id;


final_str=CONCAT(' INSERT INTO ',cuboid_list_tblname,' (ord_id,inv_id,enable_status,join_col,base_cuboid,load_cuboid,time,',base_cub_columns,') 
VALUES(',max_ord_id+1,',1,1,',quote(time_column),',',quote(base_cuboidid),',',quote(load_cuboidid),',',quote(time_column),',',base_cuboidid_columns,')  ');

EXECUTE IMMEDIATE final_str;
#echo select final_str as v;
#echo select delete_str as v1;


load_cuboidid=return_cuboidid(kpi_flag_lable,time_column,list_columns);
base_cuboidid=return_cuboidid(kpi_flag_lable,time_column,'base');

listcolumns=lower(replace(replace(list_columns,' ',''),'`',''));
listcolumns=CONCAT('''',REPLACE(listcolumns,',',''','''),'''');

delete_str=CONCAT(' DELETE FROM ',cuboid_list_tblname,' WHERE load_cuboid=',quote(load_cuboidid),'   ');

final_str=CONCAT(' INSERT INTO ',cuboid_list_tblname,' (ord_id,inv_id,enable_status,join_col,base_cuboid,load_cuboid,time,',list_columns,') 
VALUES(',max_ord_id+2,',2,1,',quote(time_column),',',quote(base_cuboidid),',',quote(load_cuboidid),',',quote(time_column),',',listcolumns,')  ');


EXECUTE IMMEDIATE delete_str;
EXECUTE IMMEDIATE final_str;
#echo select final_str as v2;
#echo select delete_str as v3;


ELSE

load_cuboidid=return_cuboidid(kpi_flag_lable,time_column,list_columns);
base_cuboidid=return_cuboidid(kpi_flag_lable,time_column,'base');

listcolumns=lower(replace(replace(list_columns,' ',''),'`',''));
listcolumns=CONCAT('''',REPLACE(listcolumns,',',''','''),'''');

delete_str=CONCAT(' DELETE FROM ',cuboid_list_tblname,' WHERE load_cuboid=',quote(load_cuboidid),'   ');

EXECUTE IMMEDIATE delete_str;


final_str=CONCAT('select nvl(min(inv_id),0),nvl(max(inv_id),0) from ',cuboid_list_tblname,' where time=',quote(time_column),'  ');

EXECUTE IMMEDIATE final_str into min_inv_id,max_inv_id;

final_str=CONCAT('select nvl(min(ord_id),0),nvl(max(ord_id),0) from ',cuboid_list_tblname,'  ');

EXECUTE IMMEDIATE final_str into min_ord_id,max_ord_id;


final_str=CONCAT(' INSERT INTO ',cuboid_list_tblname,' (ord_id,inv_id,enable_status,join_col,base_cuboid,load_cuboid,time,',list_columns,') 
VALUES(',max_ord_id+1,',',max_inv_id+1,',1,',quote(time_column),',',quote(base_cuboidid),',',quote(load_cuboidid),',',quote(time_column),',',listcolumns,')  ');


EXECUTE IMMEDIATE final_str;
#echo select final_str as v;
#echo select delete_str as v1;

END IF;


EXCEPTION
WHEN OTHERS THEN

err_msg=exception_message();

RAISE user_exception(err_msg);

end //
delimiter ;


/*
CALL cuboid_list_tbl_load_proc('industry','month','issuer_id,business_segment,action,industry_type_cd');
CALL cuboid_list_tbl_load_proc('industry','month','issuer_id,cv_card_product_type,action,industry_cd');
CALL cuboid_list_tbl_load_proc('industry','month','issuer_id,cv_scr_attrition,action,industry_cd');
*/