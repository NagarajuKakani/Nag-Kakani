delimiter //
CREATE OR REPLACE PROCEDURE `cuboid_generate_dml_proc`(kpi_flag_lable varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, procedure_type varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, procedure_name varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, calender_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, fact_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, dimension_col varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'cuboid_generate_dml_proc';
cuboidlist_table varchar(250)=CONCAT('cuboid_list_tbl_',kpi_flag_lable);
cuboid_table varchar(250)=CONCAT('cuboid_tbl_',kpi_flag_lable);


DYN_QUERY TEXT;
DML_TEXT TEXT;

COLUMNS_STRING TEXT;
METRICS_STRING TEXT;

LISTCOLUMNS_STRING TEXT;
CUBOID_LIST_STRING TEXT;
CUBOIDLIST_QUERY TEXT;
CUBOIDLIST_QUERY_TYPE TEXT;
CUBOIDLIST_ARRAY_TYPE TEXT;
METRIC_COLUMN_STRING TEXT;
CUBOID_METRIC_COLUMNS_STRING TEXT;
DECLARE_STRING_2 TEXT;

time_loop_query QUERY
(
attribute VARCHAR(255)
);

time_loop_array ARRAY(
RECORD(
attribute VARCHAR(255)
));

COLUMNS_QUERY1 QUERY
(
cub_tbl_column VARCHAR(255)
);

COLUMNS_QUERY ARRAY(
RECORD(
cub_tbl_column VARCHAR(255)
));


METRICS_QUERY1 QUERY
(
fact_col VARCHAR(255),
metric VARCHAR(255)
);

METRICS_QUERY ARRAY(
RECORD(
fact_col VARCHAR(255),
metric VARCHAR(255)
));


begin

LISTCOLUMNS_STRING='';
CUBOID_LIST_STRING='CONCAT(''T.'',TIME ';
CUBOIDLIST_QUERY=' DYN_QUERY=CONCAT(DYN_QUERY,'' '; 

CUBOIDLIST_QUERY_TYPE='
/* Cuboid List table QUERY type */
CUBOID_LIST_QUERY QUERY
(
`ord_id` varchar(255),
`join_col` varchar(255),
`base_cuboid` varchar(255),
`load_cuboid` varchar(255),
`time` varchar(255),

';

CUBOIDLIST_ARRAY_TYPE='
/* Cuboid List table ARRAY type */
CUBOID_LIST_ARRAY ARRAY(
RECORD(
`ord_id` varchar(255),
`join_col` varchar(255),
`base_cuboid` varchar(255),
`load_cuboid` varchar(255),
`time` varchar(255),

';

##Retrieving metrics from attribute mapping table
COLUMNS_STRING = CONCAT('

select cub_tbl_column from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%''  and dim_idx!=1 ORDER by dim_idx asc

');
		
COLUMNS_QUERY1 = TO_QUERY(COLUMNS_STRING);
COLUMNS_QUERY = COLLECT(COLUMNS_QUERY1);

FOR COLUMNS IN COLUMNS_QUERY
LOOP

## list_columns column in cuboid_proc_tbl table
LISTCOLUMNS_STRING=CONCAT(LISTCOLUMNS_STRING,',',COLUMNS.cub_tbl_column,'
 ');

## cuboid_list_string column in cuboid_proc_tbl table
CUBOID_LIST_STRING=CONCAT(CUBOID_LIST_STRING,'
,CASE WHEN ',COLUMNS.cub_tbl_column,'!=''0''  THEN  CONCAT('',F.'',',COLUMNS.cub_tbl_column,')  ELSE '''' END
');

## cuboid_list_query column in cuboid_proc_tbl table
CUBOIDLIST_QUERY=CONCAT(CUBOIDLIST_QUERY,' 
 '',CUBOID_LIST.',COLUMNS.cub_tbl_column,' ,'', ');

## declare_string2 column in cuboid_proc_tbl table
CUBOIDLIST_QUERY_TYPE=CONCAT(CUBOIDLIST_QUERY_TYPE,' 
 ',COLUMNS.cub_tbl_column,' varchar(255), 
');

## declare_string2 column in cuboid_proc_tbl table
CUBOIDLIST_ARRAY_TYPE=CONCAT(CUBOIDLIST_ARRAY_TYPE,' 
 ',COLUMNS.cub_tbl_column,' varchar(255),
 ');

END LOOP;

##Retrieving metrics from fact mapping table
METRICS_STRING= CONCAT('

select cub_tbl_column,cub_tbl_column_function metrics from cuboid_facts_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%''  ORDER by fact_id asc

');
		
METRICS_QUERY1 = TO_QUERY(METRICS_STRING);
METRICS_QUERY = COLLECT(METRICS_QUERY1);

CUBOID_METRIC_COLUMNS_STRING='';
METRIC_COLUMN_STRING=' ';

FOR METRICS IN METRICS_QUERY
LOOP

## metrics column in cuboid_proc_tbl table
CUBOID_METRIC_COLUMNS_STRING=CONCAT(CUBOID_METRIC_COLUMNS_STRING,',',METRICS.fact_col,'  ');

## cuboid_metric_columns column in cuboid_proc_tbl table
METRIC_COLUMN_STRING=CONCAT(METRIC_COLUMN_STRING, ' ,',METRICS.metric,' ');


END LOOP;

## list_columns column in cuboid_proc_tbl table
LISTCOLUMNS_STRING=SUBSTR(LISTCOLUMNS_STRING,2);
## cuboid_list_string column in cuboid_proc_tbl table
CUBOID_LIST_STRING=CONCAT(CUBOID_LIST_STRING,' ) GROUPING_COLUMNS ');
## cuboidlist_query column in cs_strings_proc_tbl table
CUBOIDLIST_QUERY=substring(TRIM(CUBOIDLIST_QUERY),1,length(TRIM(CUBOIDLIST_QUERY))-1);
CUBOIDLIST_QUERY=CONCAT(CUBOIDLIST_QUERY,' ''); ');
## cuboid_metric_col column in cs_strings_proc_tbl table
CUBOID_METRIC_COLUMNS_STRING=SUBSTR(CUBOID_METRIC_COLUMNS_STRING,2);

## declare_string2 column in cuboid_proc_tbl table
CUBOIDLIST_QUERY_TYPE=CONCAT(CUBOIDLIST_QUERY_TYPE,'

GROUPING_COLUMNS varchar(255)
);
');
## declare_string2 column in cuboid_proc_tbl table
CUBOIDLIST_ARRAY_TYPE=CONCAT(CUBOIDLIST_ARRAY_TYPE,'
GROUPING_COLUMNS varchar(255)
));

');

## Forming declare_string2 column in cuboid_proc_tbl table
DECLARE_STRING_2=CONCAT(CUBOIDLIST_QUERY_TYPE,'

',CUBOIDLIST_ARRAY_TYPE);



#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(LISTCOLUMNS_STRING);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOID_LIST_STRING);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOID_METRIC_COLUMNS_STRING);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(METRIC_COLUMN_STRING);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY_TYPE);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_ARRAY_TYPE);
#INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY);


DELETE FROM cuboid_proc_tbl WHERE proc_name=procedure_name and kpi_flag=kpi_flag_lable and proc_type=procedure_type;

INSERT INTO cuboid_proc_tbl
(
kpi_flag,proc_type,proc_name, calender_tbl, cuboidlist_tbl, fact_tbl, cuboid_tbl, dimension_col,
metrics,cuboid_metric_col,list_col, cuboidlist_string, declare_string2, cuboidlist_query
)
VALUES
(
kpi_flag_lable,procedure_type,procedure_name,calender_table,cuboidlist_table,fact_table,cuboid_table,dimension_col,
METRIC_COLUMN_STRING,CUBOID_METRIC_COLUMNS_STRING,LISTCOLUMNS_STRING,CUBOID_LIST_STRING,DECLARE_STRING_2,CUBOIDLIST_QUERY
);


#### Generating auto cuboid ddl proc and saving into one table 

DYN_QUERY=CONCAT('
INSERT INTO cuboid_proc_dml_tbl(kpi_flag,proc_name,dml)
SELECT "',kpi_flag_lable,'",
x.proc_name,CONCAT(REPLACE(REPLACE(y.declare_string1,\'auto_gen_cuboid_proc\',x.proc_name),\'auto_gen_cal_tbl\',x.calender_tbl),x.declare_string2,
y.body_string_begin,
');


DML_TEXT=CONCAT('
SELECT attribute FROM (select 
CASE 
WHEN UPPER(TRIM(attribute))=\'DAY\' THEN 1
WHEN UPPER(TRIM(attribute))=\'WEEK\' THEN 2
WHEN UPPER(TRIM(attribute))=\'MONTH\' THEN 3
WHEN UPPER(TRIM(attribute))=\'QUARTER\' THEN 4
WHEN UPPER(TRIM(attribute))=\'SEASON\' THEN 5
WHEN UPPER(TRIM(attribute))=\'YEAR\' THEN 6
END attr_order,X.attribute
from cuboid_attr_mapping_tbl X where UPPER(TRIM(dimension))=\'TIME\' ) X ORDER BY attr_order ASC
');

time_loop_query = TO_QUERY(DML_TEXT);
time_loop_array = COLLECT(time_loop_query);

FOR time_loop IN time_loop_array
LOOP

IF UPPER(time_loop.attribute)='DAY'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_day1,x.cuboidlist_query,y.body_string_day2, ');
ELSIF UPPER(time_loop.attribute)='WEEK'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_week1,x.cuboidlist_query,y.body_string_week2, ');
ELSIF UPPER(time_loop.attribute)='MONTH'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_month1,x.cuboidlist_query,y.body_string_month2, ');
ELSIF UPPER(time_loop.attribute)='QUARTER'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_quarter1,x.cuboidlist_query,y.body_string_quarter2, ');
ELSIF UPPER(time_loop.attribute)='SEASON'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_season1,x.cuboidlist_query,y.body_string_season2, ');
ELSIF UPPER(time_loop.attribute)='YEAR'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_year1,x.cuboidlist_query,y.body_string_year2, ');
END IF;

END LOOP;

DYN_QUERY=CONCAT(DYN_QUERY,'
y.body_string_exception) hh
from cuboid_proc_tbl x join cuboid_proc_dml_template_tbl y
where x.proc_type=y.proc_type and x.proc_type =',quote(procedure_type),'
and x.proc_name=',quote(procedure_name),'
');

DELETE FROM cuboid_proc_dml_tbl WHERE proc_name=procedure_name and kpi_flag=kpi_flag_lable;

EXECUTE IMMEDIATE DYN_QUERY;

EXCEPTION 
WHEN OTHERS THEN

ERR_MSG=exception_message();

RAISE user_exception(ERR_MSG);

end //
delimiter ;

/*
CALL cuboid_generate_dml_proc(
'industry',
'custom',
'load_industry_cuboid_tbl',
'cuboid_cal_tbl',
'cs_fact_portfolio_industry_tbl',
'issuer_id');
*/