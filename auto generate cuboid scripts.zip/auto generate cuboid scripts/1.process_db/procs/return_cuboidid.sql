DELIMITER //
CREATE OR REPLACE PROCEDURE `return_cuboidid`(kpi_flag_lable varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, time_column varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, list_columns text CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS
DECLARE
err_msg TEXT = '';
proc_name TEXT = 'return_cuboidid';

dim_max_col varchar(100)='';
max_col varchar(100)='';
cuboidid varchar(500);
listcolumns text;
final_str text;

BEGIN

IF list_columns='base'
THEN

final_str=CONCAT(' select cub_tbl_column from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' and is_dim=1 order by cuboidid_idx desc limit 1');

execute immediate final_str into dim_max_col;

final_str=CONCAT(' select cub_tbl_column from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' order by cuboidid_idx desc limit 1');

execute immediate final_str into max_col;

final_str=CONCAT(' 
SELECT CONCAT(REPLACE(GROUP_CONCAT(cub_id,cub_sep ORDER BY cuboidid_idx),'','','''')) cuboidid 
from (select cuboidid_idx,attr_code cub_id,''|'' cub_sep  from cuboid_attr_mapping_tbl
where kpi_flag like ''%',kpi_flag_lable,'%'' and dimension=''Time'' and lower(replace(trim(cub_tbl_column),''`'','''')) IN (''',time_column,''')
UNION ALL
select  cuboidid_idx,attr_code cub_id,
CASE WHEN cub_tbl_column=''',dim_max_col,''' THEN ''-'' WHEN cub_tbl_column=''',max_col,''' THEN ''''  ELSE ''|'' END cub_sep
from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' and dimension!=''Time'' order by cuboidid_idx ASC)
');

ELSE

final_str=CONCAT(' select cub_tbl_column from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' and is_dim=1 order by cuboidid_idx desc limit 1');

execute immediate final_str into dim_max_col;

final_str=CONCAT(' select cub_tbl_column from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' order by cuboidid_idx desc limit 1');

execute immediate final_str into max_col;

listcolumns=lower(replace(replace(list_columns,' ',''),'`',''));
listcolumns=CONCAT('''',REPLACE(listcolumns,',',''','''),'''');

final_str=CONCAT(' 
SELECT CONCAT(REPLACE(GROUP_CONCAT(cub_id,cub_sep ORDER BY cuboidid_idx),'','','''')) cuboidid 
from (select cuboidid_idx,attr_code cub_id,''|'' cub_sep  from cuboid_attr_mapping_tbl
where kpi_flag like ''%',kpi_flag_lable,'%'' and dimension=''Time'' and lower(replace(trim(cub_tbl_column),''`'','''')) IN (''',time_column,''')
UNION ALL
select cuboidid_idx,CASE WHEN lower(replace(trim(cub_tbl_column),''`'','''')) IN (',listcolumns,') THEN attr_code ELSE ''*'' END cub_id,
CASE WHEN cub_tbl_column=''',dim_max_col,''' THEN ''-'' WHEN cub_tbl_column=''',max_col,''' THEN ''''  ELSE ''|'' END cub_sep
from cuboid_attr_mapping_tbl where kpi_flag like ''%',kpi_flag_lable,'%'' and dimension!=''Time'' order by cuboidid_idx ASC)
');

END IF;


EXECUTE IMMEDIATE final_str INTO cuboidid;

IF SUBSTR(cuboidid,-1) IN ('-','|')
THEN cuboidid=SUBSTR(cuboidid,1,length(cuboidid)-1); 
ELSE cuboidid=cuboidid; 
END IF;

RETURN cuboidid;

EXCEPTION
WHEN OTHERS THEN

err_msg=exception_message();

RAISE user_exception(err_msg);

end //
DELIMITER ;
