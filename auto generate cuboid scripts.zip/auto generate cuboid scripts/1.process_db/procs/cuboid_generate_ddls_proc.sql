delimiter //
CREATE OR REPLACE PROCEDURE `cuboid_generate_ddls_proc`(kpi_flag_lable varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

err_msg text = "";
proc_name text = 'cuboid_generate_ddls_proc';

cuboid_list_tblname varchar(100)= CONCAT('cuboid_list_tbl_',kpi_flag_lable);
cuboid_tblname varchar(100)= CONCAT('cuboid_tbl_',kpi_flag_lable);

mst_attrmap_tblname varchar(100) = 'cuboid_attr_mapping_tbl';
mst_factsmap_tblname varchar(100) = 'cuboid_facts_mapping_tbl';

attributes_str text;
facts_str text;
cuboid_list_str text;
cuboid_str text;

timedim_dyn text;
timedim_qry query(dim_name text);
timedim_str text;

attributes_dyn text;
attributes_qry query(attribute text);
attributes_rec array(record( attribute text));
attr text;

facts_dyn text;
facts_qry query(facts text);
facts_rec array(record(facts text));
fact text;

ddl_statement text;
drop_table text;


begin

timedim_dyn = concat('select distinct dimension from ',mst_attrmap_tblname,' where kpi_flag like ''%',kpi_flag_lable,'%'' and dim_idx = 1');
timedim_qry = to_query(timedim_dyn);
timedim_str = concat(scalar(timedim_qry),' varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT ''0''');


###### attributes ######
attributes_dyn = concat('select cub_tbl_column from ',mst_attrmap_tblname,' where kpi_flag like ''%',kpi_flag_lable,'%'' and cuboidid_idx !=1 order by cuboidid_idx') ;
attributes_qry = to_query(attributes_dyn);
attributes_rec = collect(attributes_qry);

attributes_str = '';
for rec in attributes_rec 
loop

attr = concat(rec.attribute,' varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT ''0''');

attributes_str  = concat(attributes_str,',',attr);
end loop;


###### facts ######
facts_dyn = concat('select CONCAT(cub_tbl_column,''  '',datatype,'','') from ',mst_factsmap_tblname,' where kpi_flag like ''%',kpi_flag_lable,'%'' order by fact_id') ;
facts_qry = to_query(facts_dyn);
facts_rec = collect(facts_qry);

facts_str = '';
for rec in facts_rec 
loop

facts_str = concat(facts_str,rec.facts);

end loop;


###### cuboid list table #########

cuboid_list_str = concat(timedim_str,attributes_str);

drop_table = concat('drop table if exists ',cuboid_list_tblname);

ddl_statement = concat(
'CREATE TABLE ',cuboid_list_tblname,' (
`inv_id` int(11) unsigned DEFAULT null,
`ord_id` int(11) unsigned DEFAULT null,
`join_col` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT null,
`load_cuboid` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT null,
`base_cuboid` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT null,'
,cuboid_list_str,',',
'`enable_status` int(1) DEFAULT null,
`ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
`upd_ts` timestamp NULL DEFAULT null ON UPDATE CURRENT_TIMESTAMP,
KEY `ord_id` (`base_cuboid`) USING CLUSTERED COLUMNSTORE,
SHARD KEY `ord_id_2` (`ord_id`)
)
');

execute immediate  drop_table;
execute immediate  ddl_statement;


###### cuboid table #########


cuboid_str = concat(timedim_str,attributes_str,',',facts_str);

drop_table = concat('drop table if exists ',cuboid_tblname);

ddl_statement = concat(
'CREATE TABLE ',cuboid_tblname,' (
`cuboidid` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT null,'
,cuboid_str,
'`ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
`upd_ts` timestamp NULL DEFAULT null ON UPDATE CURRENT_TIMESTAMP,
KEY `cuboidid` (`cuboidid`) USING CLUSTERED COLUMNSTORE,
SHARD KEY `cuboidid_1` (`cuboidid`)
)
');

execute immediate  drop_table;
execute immediate  ddl_statement;


exception 
when others then
err_msg=exception_message();
raise user_exception(err_msg);

end //
delimiter ;

/* CALL cuboid_generate_ddls_proc('industry'); */