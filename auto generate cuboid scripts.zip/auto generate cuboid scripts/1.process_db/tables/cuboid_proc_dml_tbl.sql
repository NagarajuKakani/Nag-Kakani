CREATE TABLE `cuboid_proc_dml_tbl` (
  `proc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dml` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `compile_status` int(11) DEFAULT 0,
  `kpi_flag` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
  /*!90618 , SHARD KEY () */ 
) /*!90623 AUTOSTATS_CARDINALITY_MODE=OFF, AUTOSTATS_HISTOGRAM_MODE=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;