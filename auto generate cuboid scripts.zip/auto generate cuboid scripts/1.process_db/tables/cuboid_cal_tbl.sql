CREATE TABLE `cuboid_cal_tbl` (
  `trxn_dt` date NOT NULL DEFAULT '0000-00-00 00:00:00',
  `NRF_YEAR` smallint(6) DEFAULT NULL,
  `NRF_WEEK` tinyint(4) DEFAULT NULL,
  `NRF_MONTH` tinyint(4) DEFAULT NULL,
  `NRF_SEASON` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `NRF_QUARTER` tinyint(4) DEFAULT NULL,
  `NRF_DAY` smallint(6) DEFAULT NULL,
  `day` mediumint(9) DEFAULT NULL,
  `week` mediumint(9) DEFAULT NULL,
  `month` mediumint(9) DEFAULT NULL,
  `quarter` mediumint(9) DEFAULT NULL,
  `season` smallint(6) DEFAULT NULL,
  `year` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`trxn_dt`)
) /*!90623 AUTOSTATS_CARDINALITY_MODE=OFF, AUTOSTATS_HISTOGRAM_MODE=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;