CREATE TABLE `cuboid_proc_tbl` (
  `proc_type` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `proc_name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `calender_tbl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `cuboidlist_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fact_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboid_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dimension_col` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'UNKNOWN',
  `metrics` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboid_metric_col` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `list_col` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboidlist_string` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `declare_string2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `cuboidlist_query` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `upd_ts` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `kpi_flag` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  KEY `cuboidid_idx` (`cuboid_tbl`,`fact_tbl`,`cuboidlist_tbl`) /*!90619 USING CLUSTERED COLUMNSTORE */,
  /*!90618 SHARD */ KEY `cuboidid` (`cuboid_tbl`,`fact_tbl`,`cuboidlist_tbl`)
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=OFF, AUTOSTATS_SAMPLING=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;