CREATE TABLE `cuboid_proc_dml_template_tbl` (
  `proc_type` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `declare_string1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_begin` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_day1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_day2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_week1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_week2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_month1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_month2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_quarter1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_quarter2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_season1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_season2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_year1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_year2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_exception` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  KEY `STRINGS_IDX` (`declare_string1`,`body_string_begin`) /*!90619 USING CLUSTERED COLUMNSTORE */,
  /*!90618 SHARD */ KEY `declare_string1` (`declare_string1`,`body_string_begin`)
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=OFF, AUTOSTATS_SAMPLING=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;