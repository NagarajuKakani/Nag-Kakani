Assumptions
--------------
1. Cuboid list column names and its values should be same even for dimensions and its attributes except CUBOIDID and TIME columns and its dimension columns Default value should be 'NOT-KNOWN' and CUBOIDID,TIME columns should be 1st and 2nd columns of its ddl. Channel Column also should be included in Channel list table.
2. Order of cuboid list ddl columns should be match to fact and cuboid table ddl.
3. For calender table column names should be day,week,month,quarter,season,year. How ever the value wil be in it.
4. 

DML Cuboid Metadata table
-------------------------
1. FACT_TBL_NAME column name should be renamed to FACT_VW_NAME.
2. AGG_METRICS ,DAILY_METRICS  need to be maintian one column as METRICS for both Fact and Cuboid tables.
3. Fact table query column removed.
4. Cuboid id column should be removed.
 
Fact View Creation
--------------------
1. SHPG_TRXN_LN_DT in Fact table should be aliased as TRXN_DT in FACT_VW_NAME.

Have to Work
---------------
1. May be we should maintain Daily metrics and Agg Metrics seperately since the Agg functions may vary on fact table and cuboid table --- AGG_METRICS ,DAILY_METRICS  need to be maintian one column as METRICS for both Fact and Cuboid tables --- Have to dicsuss.
2. in cuboid template table digital table has to add digital fact table names should be add in cuboid proc table.

Discussion Points
------------------
1. Cuboid Data Caluculation interms of using cuboid list table every time.
2. Passing channel as parameter in procedure.
3. Order of parameters in procedure if channel became the optional parameter.
4. If channel is treating as any other attribute in procedure channel related select,insert,delete statements has to adjust.




1. For each time level there should be one column cuboid template table so that in query we can for our req timelevel proc based on requirement.
2. In Calender table there should be all timelevel columns has to present whether we use  some timelevels or not -- but has to check while using time variable values in delete,select statement.
3. Delete query has to adjust within IF ELSE since some times we will run only base level cuboids some time not so how to delete those -- Have to discuss with the team.
4. in My view am maintaing any transaction date column as TRXN_DT  since i couldn't get it in runtime.


1. Fact table view txn date   alias should be TIME just to adjust code in dml proc.
2. Fact view should consists all day,week,month etc...