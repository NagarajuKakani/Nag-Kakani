
Run this below proc with appropriate values
-------------------------------------
CALL auto_dml_cuboid_template_tbl_population('auto_gen_cuboid_sales','general','auto_gen_cuboid_sales','RS_STG_NRF_CAL_TBL','FACT_TBL','CUBLIST_TBL','CUB_TBL','DPSCT-1A1B','channel');


select proc_name,dml
from auto_gen_cuboid_dml;

##compile dml value as a script available in above table.



Run Cuboid data loading in following style
-----------------------------------------
CALL auto_gen_cuboid_sales('01-01-2019','30-06-2019','D','1');
