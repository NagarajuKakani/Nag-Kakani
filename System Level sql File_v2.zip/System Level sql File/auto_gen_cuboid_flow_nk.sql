##### Debugging Specific #########

CREATE TABLE `rs_dp_stats_tbl` (
  `proc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `err_msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  /*!90618 , SHARD KEY () */ 
) /*!90623 AUTOSTATS_CARDINALITY_MODE=OFF, AUTOSTATS_HISTOGRAM_MODE=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `TEMP_TABLE` (
  `DYN_TEXT` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `INS_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  /*!90618 , SHARD KEY () */ 
) /*!90623 AUTOSTATS_CARDINALITY_MODE=OFF, AUTOSTATS_HISTOGRAM_MODE=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

######### Cuboid Specific scripts ###########
CREATE TABLE `cs_cuboid_proc_tbl` (
  `proc_type` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `proc_name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `calender_tbl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `cuboidlist_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fact_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboid_tbl` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dimension_col` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboidid` varchar(600) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `metrics` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboid_metric_col` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `list_col` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cuboidlist_string` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `declare_string2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `cuboidlist_query` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `ins_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `upd_ts` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY `cuboidid_idx` (`cuboid_tbl`,`fact_tbl`,`cuboidlist_tbl`) /*!90619 USING CLUSTERED COLUMNSTORE */,
  /*!90618 SHARD */ KEY `cuboidid` (`cuboid_tbl`,`fact_tbl`,`cuboidlist_tbl`)
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=OFF, AUTOSTATS_SAMPLING=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `cs_cuboid_dml_template_tbl` (
`proc_type` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `declare_string1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_begin` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_day1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_day2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_week1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_week2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_month1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_month2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_quarter1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_quarter2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_season1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_season2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_year1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_year2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `body_string_exception` text CHARACTER SET utf8 COLLATE utf8_general_ci,
   KEY `STRINGS_IDX` (`declare_string1`,`body_string_begin`) /*!90619 USING CLUSTERED COLUMNSTORE */,
  /*!90618 SHARD */ KEY `declare_string1` (`declare_string1`,`body_string_begin`)
) /*!90623 AUTOSTATS_CARDINALITY_MODE=INCREMENTAL, AUTOSTATS_HISTOGRAM_MODE=OFF, AUTOSTATS_SAMPLING=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

CREATE TABLE `auto_gen_cuboid_dml` (
  `proc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dml` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `compile_status` int DEFAULT 0
   /*!90618 , SHARD KEY () */ 
) /*!90623 AUTOSTATS_CARDINALITY_MODE=OFF, AUTOSTATS_HISTOGRAM_MODE=OFF */ /*!90623 SQL_MODE='STRICT_ALL_TABLES' */
;

#### Auto dml cuboid proc iserts ##########
insert into cs_cuboid_dml_template_tbl
(proc_type,
 declare_string1,
 body_string_begin,
 body_string_day1,
 body_string_day2,
 body_string_week1,
 body_string_week2,
 body_string_month1,
 body_string_month2,
 body_string_quarter1,
 body_string_quarter2,
 body_string_season1,
 body_string_season2,
 body_string_year1,
 body_string_year2,
 body_string_exception)
values
('general',
'delimiter //
CREATE OR REPLACE PROCEDURE `auto_gen_cuboid_proc`(fromdate date NOT NULL, todate date NOT NULL, timelevel varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, dimensionlevel varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT \'unknown\') RETURNS void AS
declare

/* Parameter variables */
ERR_MSG varchar(4000) = "";
PROC_NAME varchar(50) = \'auto_gen_cuboid_proc\';
calender_table varchar(50)=\'auto_gen_cal_tbl\';
START_DATE Date =fromdate;
END_DATE Date =todate;
cuboidid_level varchar(5)=upper(timelevel);
dimension_level varchar(100)=REPLACE(dimensionlevel,\'unknown\',\'UNKNOWN\');

/* Local Varibles */
fromtime varchar(50);
totime varchar(50);
cuboid_tmplate_columns text;
DYN_QUERY text;

/* Base Cuboids */
second_base_cuboidid varchar(50);
minute_base_cuboidid varchar(50);
hour_base_cuboidid varchar(50);
day_base_cuboidid varchar(50);
week_base_cuboidid varchar(50);
month_base_cuboidid varchar(50);
quarter_base_cuboidid varchar(50);
season_base_cuboidid varchar(50);
year_base_cuboidid varchar(50);


/* Cuboid metadata table QUERY type */
cuboid_metadata_query QUERY
(
cuboidid varchar(255),
fact_tbl varchar(255),
cuboidlist_tbl varchar(255),
cuboid_tbl varchar(255),
dimension_col varchar(255),
metrics varchar(4000),
cuboid_metric_col varchar(4000),
list_col text,
cuboidlist_string text,
cuboidlist_query  text
);

/* Cuboid metadata table ARRAY type */
cuboid_metadata_array ARRAY(
RECORD(
cuboidid varchar(255),
fact_tbl varchar(255),
cuboidlist_tbl varchar(255),
cuboid_tbl varchar(255),
dimension_col varchar(255),
metrics varchar(4000),
cuboid_metric_col varchar(4000),
list_col text,
cuboidlist_string text,
cuboidlist_query  text
));
',
'begin

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Started\',ERR_MSG);

cuboid_tmplate_columns=
\'
cuboidid,
fact_tbl,
cuboidlist_tbl,
cuboid_tbl,
dimension_col,
metrics,
cuboid_metric_col,
list_col,
cuboidlist_string,
cuboidlist_query
\';

DYN_QUERY=CONCAT(\' SELECT \',cuboid_tmplate_columns,\' FROM cs_cuboid_proc_tbl where PROC_NAME="\',PROC_NAME,\'" \');

cuboid_metadata_query = TO_QUERY(DYN_QUERY);
cuboid_metadata_array = COLLECT(cuboid_metadata_query);

############# Day Level Dynamic Loading 

FOR cuboid_metadata IN cuboid_metadata_array
LOOP

######## Defining Base Cuboids of All Time Levels
second_base_cuboidid=CONCAT(\'s\',SUBSTR(cuboid_metadata.`cuboidid`,2));
minute_base_cuboidid=CONCAT(\'m\',SUBSTR(cuboid_metadata.`cuboidid`,2));
hour_base_cuboidid=CONCAT(\'h\',SUBSTR(cuboid_metadata.`cuboidid`,2));
day_base_cuboidid=CONCAT(\'D\',SUBSTR(cuboid_metadata.`cuboidid`,2));
week_base_cuboidid=CONCAT(\'W\',SUBSTR(cuboid_metadata.`cuboidid`,2));
month_base_cuboidid=CONCAT(\'M\',SUBSTR(cuboid_metadata.`cuboidid`,2));
quarter_base_cuboidid=CONCAT(\'Q\',SUBSTR(cuboid_metadata.`cuboidid`,2));
season_base_cuboidid=CONCAT(\'S\',SUBSTR(cuboid_metadata.`cuboidid`,2));
year_base_cuboidid=CONCAT(\'Y\',SUBSTR(cuboid_metadata.`cuboidid`,2));
',
'####################### Day Level Cuboid Load ######################

IF (cuboidid_level=\'D\' OR cuboidid_level=\'DB\' OR cuboidid_level=\'DNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN	

################### Populating cuboids For Day Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
					\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
					 FROM \',cuboid_metadata.cuboidlist_tbl,\'
					 WHERE enable_status=1 
				 \');                 
IF (cuboidid_level=\'DB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',day_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'DNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',day_base_cuboidid,\'" AND load_cuboid LIKE \'\'D%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'D%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# Day Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=day_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;


DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,F.\',CUBOID_LIST.time,\' time,
        \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\'
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');
	-- Time Level Filter
	IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
	THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
	ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
	THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'D%\'\'  \');
	ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
	END IF;
END IF;

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' ) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\' ) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;


IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

ELSE

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.time,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;

END LOOP;

END IF;
',
'####################### Week Level Cuboid Load ######################
    
IF (cuboidid_level=\'W\' OR cuboidid_level=\'WB\' OR cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For Week Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',week_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',week_base_cuboidid,\'"  AND load_cuboid LIKE \'\'W%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'W%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# Week Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=week_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'D%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### month Level Cuboid Load ######################
    
IF (cuboidid_level=\'M\' OR cuboidid_level=\'MB\' OR cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For month Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'MB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',month_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',month_base_cuboidid,\'"  AND load_cuboid LIKE \'\'M%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'M%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# month Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=month_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'MB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'W%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join and Time Column values are same to avoid duplicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### quarter Level Cuboid Load ######################
    
IF (cuboidid_level=\'Q\' OR cuboidid_level=\'QB\' OR cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For quarter Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'QB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',quarter_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',quarter_base_cuboidid,\'"  AND load_cuboid LIKE \'\'Q%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'Q%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# quarter Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=quarter_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'QB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'M%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### season Level Cuboid Load ######################
    
IF (cuboidid_level=\'S\' OR cuboidid_level=\'SB\' OR cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For season Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'SB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',season_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',season_base_cuboidid,\'"  AND load_cuboid LIKE \'\'S%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'S%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# season Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=season_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'SB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'Q%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### year Level Cuboid Load ######################
    
IF (cuboidid_level=\'Y\' OR cuboidid_level=\'YB\' OR cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For year Level #################
DYN_QUERY =CONCAT(\'SELECT ord_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'YB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',year_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',year_base_cuboidid,\'"  AND load_cuboid LIKE \'\'Y%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'Y%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY ORD_ID ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# year Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=year_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'YB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'S%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'END LOOP;

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Finished\',ERR_MSG);

EXCEPTION 
WHEN OTHERS THEN

ERR_MSG=exception_message();

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Errors\',ERR_MSG);

RAISE user_exception(ERR_MSG);

end //
delimiter ;');


insert into cs_cuboid_dml_template_tbl
(proc_type,
 declare_string1,
 body_string_begin,
 body_string_day1,
 body_string_day2,
 body_string_week1,
 body_string_week2,
 body_string_month1,
 body_string_month2,
 body_string_quarter1,
 body_string_quarter2,
 body_string_season1,
 body_string_season2,
 body_string_year1,
 body_string_year2,
 body_string_exception)
values
('custom',
'delimiter //
CREATE OR REPLACE PROCEDURE `auto_gen_cuboid_proc`(fromdate date NOT NULL, todate date NOT NULL, timelevel varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, dimensionlevel varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT \'unknown\') RETURNS void AS
declare

/* Parameter variables */
ERR_MSG varchar(4000) = "";
PROC_NAME varchar(50) = \'auto_gen_cuboid_proc\';
calender_table varchar(50)=\'auto_gen_cal_tbl\';
START_DATE Date =fromdate;
END_DATE Date =todate;
cuboidid_level varchar(5)=upper(timelevel);
dimension_level varchar(100)=REPLACE(dimensionlevel,\'unknown\',\'UNKNOWN\');

/* Local Varibles */
fromtime varchar(50);
totime varchar(50);
cuboid_tmplate_columns text;
DYN_QUERY text;

/* Base Cuboids */
second_base_cuboidid varchar(50);
minute_base_cuboidid varchar(50);
hour_base_cuboidid varchar(50);
day_base_cuboidid varchar(50);
week_base_cuboidid varchar(50);
month_base_cuboidid varchar(50);
quarter_base_cuboidid varchar(50);
season_base_cuboidid varchar(50);
year_base_cuboidid varchar(50);


/* Cuboid metadata table QUERY type */
cuboid_metadata_query QUERY
(
cuboidid varchar(255),
fact_tbl varchar(255),
cuboidlist_tbl varchar(255),
cuboid_tbl varchar(255),
dimension_col varchar(255),
metrics varchar(4000),
cuboid_metric_col varchar(4000),
list_col text,
cuboidlist_string text,
cuboidlist_query  text
);

/* Cuboid metadata table ARRAY type */
cuboid_metadata_array ARRAY(
RECORD(
cuboidid varchar(255),
fact_tbl varchar(255),
cuboidlist_tbl varchar(255),
cuboid_tbl varchar(255),
dimension_col varchar(255),
metrics varchar(4000),
cuboid_metric_col varchar(4000),
list_col text,
cuboidlist_string text,
cuboidlist_query  text
));
',
'begin

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Started\',ERR_MSG);

cuboid_tmplate_columns=
\'
cuboidid,
fact_tbl,
cuboidlist_tbl,
cuboid_tbl,
dimension_col,
metrics,
cuboid_metric_col,
list_col,
cuboidlist_string,
cuboidlist_query
\';

DYN_QUERY=CONCAT(\' SELECT \',cuboid_tmplate_columns,\' FROM cs_cuboid_proc_tbl where proc_name="\',PROC_NAME,\'" \');

cuboid_metadata_query = TO_QUERY(DYN_QUERY);
cuboid_metadata_array = COLLECT(cuboid_metadata_query);

############# Day Level Dynamic Loading 

FOR cuboid_metadata IN cuboid_metadata_array
LOOP

######## Defining Base Cuboids of All Time Levels
second_base_cuboidid=CONCAT(\'s\',SUBSTR(cuboid_metadata.`cuboidid`,2));
minute_base_cuboidid=CONCAT(\'m\',SUBSTR(cuboid_metadata.`cuboidid`,2));
hour_base_cuboidid=CONCAT(\'h\',SUBSTR(cuboid_metadata.`cuboidid`,2));
day_base_cuboidid=CONCAT(\'D\',SUBSTR(cuboid_metadata.`cuboidid`,2));
week_base_cuboidid=CONCAT(\'W\',SUBSTR(cuboid_metadata.`cuboidid`,2));
month_base_cuboidid=CONCAT(\'M\',SUBSTR(cuboid_metadata.`cuboidid`,2));
quarter_base_cuboidid=CONCAT(\'Q\',SUBSTR(cuboid_metadata.`cuboidid`,2));
season_base_cuboidid=CONCAT(\'S\',SUBSTR(cuboid_metadata.`cuboidid`,2));
year_base_cuboidid=CONCAT(\'Y\',SUBSTR(cuboid_metadata.`cuboidid`,2));
',
'####################### Day Level Cuboid Load ######################

IF (cuboidid_level=\'D\' OR cuboidid_level=\'DB\' OR cuboidid_level=\'DNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN	

################### Populating cuboids For Day Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
					\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
					 FROM \',cuboid_metadata.cuboidlist_tbl,\'
					 WHERE enable_status=1 
				 \');                 
IF (cuboidid_level=\'DB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',day_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'DNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',day_base_cuboidid,\'" AND load_cuboid LIKE \'\'D%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'D%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# Day Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=day_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;


DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,F.\',CUBOID_LIST.time,\' time,
        \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\'
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');
	-- Time Level Filter
	IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
	THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
	ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
	THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'D%\'\'  \');
	ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
	END IF;
END IF;

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' ) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\' ) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;


IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

ELSE

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.time,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;

END LOOP;

END IF;
',
'####################### Week Level Cuboid Load ######################
    
IF (cuboidid_level=\'W\' OR cuboidid_level=\'WB\' OR cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For Week Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',week_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',week_base_cuboidid,\'"  AND load_cuboid LIKE \'\'W%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'W%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# Week Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=week_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'WB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'WNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'D%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### month Level Cuboid Load ######################
    
IF (cuboidid_level=\'M\' OR cuboidid_level=\'MB\' OR cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For month Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'MB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',month_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',month_base_cuboidid,\'"  AND load_cuboid LIKE \'\'M%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'M%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# month Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=month_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'MB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'MNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'W%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join and Time Column values are same to avoid duplicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### quarter Level Cuboid Load ######################
    
IF (cuboidid_level=\'Q\' OR cuboidid_level=\'QB\' OR cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For quarter Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'QB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',quarter_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',quarter_base_cuboidid,\'"  AND load_cuboid LIKE \'\'Q%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'Q%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# quarter Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=quarter_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'QB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'QNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'M%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### season Level Cuboid Load ######################
    
IF (cuboidid_level=\'S\' OR cuboidid_level=\'SB\' OR cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For season Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'SB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',season_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',season_base_cuboidid,\'"  AND load_cuboid LIKE \'\'S%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'S%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# season Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=season_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'SB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'SNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'Q%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'####################### year Level Cuboid Load ######################
    
IF (cuboidid_level=\'Y\' OR cuboidid_level=\'YB\' OR cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\' OR cuboidid_level=\'B\' OR cuboidid_level=\'A\')
THEN

################### Populating cuboids For year Level #################
DYN_QUERY =CONCAT(\'SELECT inv_id,join_col,base_cuboid,load_cuboid,time,
                    \',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboidlist_string,\'
                
                     FROM \',cuboid_metadata.cuboidlist_tbl,\'
                     WHERE enable_status=1 
                 \');                 
IF (cuboidid_level=\'YB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid="\',year_base_cuboidid,\'" \');
ELSIF (cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid!="\',year_base_cuboidid,\'"  AND load_cuboid LIKE \'\'Y%\'\'\');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND load_cuboid LIKE \'\'Y%\'\' \');
END IF;
DYN_QUERY=CONCAT(DYN_QUERY,\' ORDER BY inv_id ASC \') ;

CUBOID_LIST_QUERY = TO_QUERY(DYN_QUERY);
CUBOID_LIST_ARRAY = COLLECT(CUBOID_LIST_QUERY);

############# year Level Dynamic Loading 

FOR CUBOID_LIST IN CUBOID_LIST_ARRAY
LOOP

IF CUBOID_LIST.load_cuboid=year_base_cuboidid
THEN

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\' 
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
                \',cuboid_metadata.`list_col`,\' \',cuboid_metadata.`metrics`,\' 
\');    

-- Granular Base Cuboid check across all time levels
IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM \',cuboid_metadata.fact_tbl,\' WHERE time BETWEEN "\',fromdate,\'" AND "\',todate,\'" \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\' FROM (SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\'  WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" \');

-- Time Level Filter
IF (cuboidid_level=\'YB\' OR cuboidid_level=\'B\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
ELSIF (cuboidid_level=\'YNB\' OR cuboidid_level=\'NB\')
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid!="\',CUBOID_LIST.base_cuboid,\'" AND cuboidid LIKE \'\'S%\'\'  \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' AND cuboidid="\',CUBOID_LIST.base_cuboid,\'" \');
END IF;

END IF;


-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

-- Check Join Column and Time Column same to avoid dupicate column error
IF CUBOID_LIST.join_col=CUBOID_LIST.time
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
ELSE 
DYN_QUERY=CONCAT(DYN_QUERY,\'
) F, (SELECT DISTINCT \',CUBOID_LIST.join_col,\',\',CUBOID_LIST.time,\' FROM \',calender_table,\'  
WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
\');
END IF;

IF CUBOID_LIST.ord_id=1
THEN
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.\',CUBOID_LIST.join_col,\' = T.\',CUBOID_LIST.join_col,\' 
GROUP BY T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
ELSE
DYN_QUERY=CONCAT(DYN_QUERY,\'
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY F.cuboidid,T.\',CUBOID_LIST.time,\',\',cuboid_metadata.`list_col`,\'  \');
END IF;


EXECUTE IMMEDIATE DYN_QUERY;

ELSE

fromtime=time_level_proc(\'F\',fromdate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);
totime=time_level_proc(\'L\',todate,CUBOID_LIST.join_col,CUBOID_LIST.time,calender_table);

DYN_QUERY=CONCAT(\' DELETE FROM \',cuboid_metadata.cuboid_tbl,\' WHERE cuboidid = "\',CUBOID_LIST.load_cuboid,\'" AND time between "\',fromtime,\'" and "\',totime,\'" 
\');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

EXECUTE IMMEDIATE DYN_QUERY;

DYN_QUERY=CONCAT(\' INSERT INTO \',cuboid_metadata.cuboid_tbl,\'  
(cuboidid,time,\',cuboid_metadata.`list_col`,\',\',cuboid_metadata.cuboid_metric_col,\')
SELECT  "\',CUBOID_LIST.load_cuboid,\'" cuboidid,T.\',CUBOID_LIST.time,\' time,
\');
',
'DYN_QUERY=CONCAT(DYN_QUERY,\'
\',cuboid_metadata.`metrics`,\' 

FROM 
(
SELECT * FROM  \',cuboid_metadata.cuboid_tbl,\' WHERE time BETWEEN "\',fromtime,\'" and "\',totime,\'" AND cuboidid = "\',CUBOID_LIST.base_cuboid,\'" \');

-- Dimension Column Filter --
IF dimension_level != \'UNKNOWN\'
THEN DYN_QUERY=CONCAT(DYN_QUERY,\' AND \',cuboid_metadata.dimension_col,\'="\',dimension_level,\'" \');
ELSE DYN_QUERY=CONCAT(DYN_QUERY,\' \');
END IF;

DYN_QUERY=CONCAT(DYN_QUERY,\' 
) F, (SELECT \',CUBOID_LIST.join_col,\' FROM \',calender_table,\' WHERE \',CUBOID_LIST.join_col,\' BETWEEN "\',fromtime,\'" and "\',totime,\'" ) T 
WHERE F.time = T.\',CUBOID_LIST.join_col,\' 
GROUP BY \',CUBOID_LIST.GROUPING_COLUMNS,\' 
\');

EXECUTE IMMEDIATE DYN_QUERY;

END IF;
END LOOP;
END IF;
',
'END LOOP;

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Finished\',ERR_MSG);

EXCEPTION 
WHEN OTHERS THEN

ERR_MSG=exception_message();

# # Execution stats and Errors Tracking procedure
insert into rs_dp_stats_tbl (proc_name, start_date, end_date,status,err_msg)
VALUES (PROC_NAME,START_DATE,END_DATE,\'Errors\',ERR_MSG);

RAISE user_exception(ERR_MSG);

end //
delimiter ;');

#####

#### time level proc ###

delimiter //
CREATE OR REPLACE PROCEDURE `time_level_proc`(first_or_last text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, run_date date NOT NULL, join_col text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, time_col text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, calendertblname text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'RS_STG_NRF_CAL_TBL') RETURNS varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS

declare
err_msg text = "";
proc_name text = 'time_level_proc';
rundate date = run_date;

from_range_dyn text;
from_range_qry query(time text);
from_range text;

from_range_time_dyn text;
from_range_time_qry query(a int);
from_range_time int;

to_range_dyn text;
to_range_qry query(time text);
to_range text;

to_range_time_dyn text;
to_range_time_qry query(b int);
to_range_time int;

range_time text;

BEGIN
IF first_or_last = 'F'
THEN
from_range_dyn = concat('select distinct ',time_col,' from ',calendertblname,' where shpg_trxn_ln_dt = "',rundate,'" ');
from_range_qry = to_query(from_range_dyn);
from_range = scalar(from_range_qry);

from_range_time_dyn = concat('select min(',join_col,') as a from ',calendertblname,' where ',time_col,' = "',from_range,'" ');
from_range_time_qry = to_query(from_range_time_dyn);
range_time = scalar(from_range_time_qry);
#echo select from_range_time as frt;


ELSIF first_or_last = 'L'
THEN
to_range_dyn = concat('select distinct ',time_col,' from ',calendertblname,' where shpg_trxn_ln_dt = "',rundate,'" ');
to_range_qry = to_query(to_range_dyn);
to_range = scalar(to_range_qry);


to_range_time_dyn = concat('select max(',join_col,') as b from ',calendertblname,' where ',time_col,' = "',to_range,'" ');
to_range_time_qry = to_query(to_range_time_dyn);
range_time = scalar(to_range_time_qry); 
#echo select to_range_time as trt;

END IF; 

 return range_time;

end //
delimiter ;

####

delimiter //
CREATE OR REPLACE PROCEDURE `auto_dml_cuboid_template_tbl_population`(flag varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, procedure_type varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, procedure_name varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, calender_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, fact_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ciNULL, cuboidlist_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, cuboid_table varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, cuboidid varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL, dimension_col varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
declare

ERR_MSG text = "";
PROC_NAME text = 'auto_dml_cuboid_template_tbl_population';

DYN_QUERY TEXT;
DML_TEXT TEXT;

COLUMNS_STRING TEXT;
METRICS_STRING TEXT;

LISTCOLUMNS_STRING TEXT;
CUBOID_LIST_STRING TEXT;
CUBOIDLIST_QUERY TEXT;
CUBOIDLIST_QUERY_TYPE TEXT;
CUBOIDLIST_ARRAY_TYPE TEXT;
METRIC_COLUMN_STRING TEXT;
CUBOID_METRIC_COLUMNS_STRING TEXT;
DECLARE_STRING_2 TEXT;

time_loop_query QUERY
(
attribute VARCHAR(255)
);

time_loop_array ARRAY(
RECORD(
attribute VARCHAR(255)
));

COLUMNS_QUERY1 QUERY
(
col_name VARCHAR(255)
);

COLUMNS_QUERY ARRAY(
RECORD(
col_name VARCHAR(255)
));


METRICS_QUERY1 QUERY
(
fact_col VARCHAR(255),
metric VARCHAR(255)
);

METRICS_QUERY ARRAY(
RECORD(
fact_col VARCHAR(255),
metric VARCHAR(255)
));


begin

LISTCOLUMNS_STRING='';
CUBOID_LIST_STRING='CONCAT(''T.'',TIME ';
CUBOIDLIST_QUERY=' DYN_QUERY=CONCAT(DYN_QUERY,'' '; 

CUBOIDLIST_QUERY_TYPE='
/* Cuboid List table QUERY type */
CUBOID_LIST_QUERY QUERY
(
`ord_id` varchar(255),
`join_col` varchar(255),
`base_cuboid` varchar(255),
`load_cuboid` varchar(255),
`time` varchar(255),

';

CUBOIDLIST_ARRAY_TYPE='
/* Cuboid List table ARRAY type */
CUBOID_LIST_ARRAY ARRAY(
RECORD(
`ord_id` varchar(255),
`join_col` varchar(255),
`base_cuboid` varchar(255),
`load_cuboid` varchar(255),
`time` varchar(255),

';

##Retrieving metrics from attribute mapping table
COLUMNS_STRING = CONCAT('

select col_name from cuboid_attr_mapping_tbl where fact_tbl="',flag,'"  and dim_idx!=1 ORDER by dim_idx asc

');
		
COLUMNS_QUERY1 = TO_QUERY(COLUMNS_STRING);
COLUMNS_QUERY = COLLECT(COLUMNS_QUERY1);

FOR COLUMNS IN COLUMNS_QUERY
LOOP

## list_columns column in cs_cuboid_proc_tbl table
LISTCOLUMNS_STRING=CONCAT(LISTCOLUMNS_STRING,',',COLUMNS.col_name,'
 ');

## cuboid_list_string column in cs_cuboid_proc_tbl table
CUBOID_LIST_STRING=CONCAT(CUBOID_LIST_STRING,'
,CASE WHEN ',COLUMNS.col_name,'!=''0''  THEN  CONCAT('',F.'',',COLUMNS.col_name,')  ELSE '''' END
');

## cuboid_list_query column in cs_cuboid_proc_tbl table
CUBOIDLIST_QUERY=CONCAT(CUBOIDLIST_QUERY,' 
 '',CUBOID_LIST.',COLUMNS.col_name,' ,'', ');

## declare_string2 column in cs_cuboid_proc_tbl table
CUBOIDLIST_QUERY_TYPE=CONCAT(CUBOIDLIST_QUERY_TYPE,' 
 ',COLUMNS.col_name,' varchar(255), 
');

## declare_string2 column in cs_cuboid_proc_tbl table
CUBOIDLIST_ARRAY_TYPE=CONCAT(CUBOIDLIST_ARRAY_TYPE,' 
 ',COLUMNS.col_name,' varchar(255),
 ');

END LOOP;

##Retrieving metrics from fact mapping table
METRICS_STRING= CONCAT('

select fact_col,factfunction metrics from cuboid_facts_mapping_tbl where fact_tbl="',flag,'"  ORDER by id asc

');
		
METRICS_QUERY1 = TO_QUERY(METRICS_STRING);
METRICS_QUERY = COLLECT(METRICS_QUERY1);

CUBOID_METRIC_COLUMNS_STRING='';
METRIC_COLUMN_STRING=' ';

FOR METRICS IN METRICS_QUERY
LOOP

## metrics column in cs_cuboid_proc_tbl table
CUBOID_METRIC_COLUMNS_STRING=CONCAT(CUBOID_METRIC_COLUMNS_STRING,',',METRICS.fact_col,'  ');

## cuboid_metric_columns column in cs_cuboid_proc_tbl table
METRIC_COLUMN_STRING=CONCAT(METRIC_COLUMN_STRING, ' ,',METRICS.metric,' ');


END LOOP;

## list_columns column in cs_cuboid_proc_tbl table
LISTCOLUMNS_STRING=SUBSTR(LISTCOLUMNS_STRING,2);
## cuboid_list_string column in cs_cuboid_proc_tbl table
CUBOID_LIST_STRING=CONCAT(CUBOID_LIST_STRING,' ) GROUPING_COLUMNS ');
## cuboidlist_query column in cs_strings_proc_tbl table
CUBOIDLIST_QUERY=substring(TRIM(CUBOIDLIST_QUERY),1,length(TRIM(CUBOIDLIST_QUERY))-1);
CUBOIDLIST_QUERY=CONCAT(CUBOIDLIST_QUERY,' ''); ');
## cuboid_metric_col column in cs_strings_proc_tbl table
CUBOID_METRIC_COLUMNS_STRING=SUBSTR(CUBOID_METRIC_COLUMNS_STRING,2);

## declare_string2 column in cs_cuboid_proc_tbl table
CUBOIDLIST_QUERY_TYPE=CONCAT(CUBOIDLIST_QUERY_TYPE,'

GROUPING_COLUMNS varchar(255)
);
');
## declare_string2 column in cs_cuboid_proc_tbl table
CUBOIDLIST_ARRAY_TYPE=CONCAT(CUBOIDLIST_ARRAY_TYPE,'
GROUPING_COLUMNS varchar(255)
));

');

## Forming declare_string2 column in cs_cuboid_proc_tbl table
DECLARE_STRING_2=CONCAT(CUBOIDLIST_QUERY_TYPE,'

',CUBOIDLIST_ARRAY_TYPE);


/*
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(LISTCOLUMNS_STRING);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOID_LIST_STRING);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOID_METRIC_COLUMNS_STRING);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(METRIC_COLUMN_STRING);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY_TYPE);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_ARRAY_TYPE);
INSERT INTO TEMP_TABLE(DYN_TEXT) VALUES(CUBOIDLIST_QUERY);
*/

INSERT INTO cs_cuboid_proc_tbl
(
proc_type,proc_name, calender_tbl, cuboidlist_tbl, fact_tbl, cuboid_tbl, dimension_col, cuboidid, 
metrics,cuboid_metric_col,list_col, cuboidlist_string, declare_string2, cuboidlist_query
)
VALUES
(
procedure_type,procedure_name,calender_table,cuboidlist_table,fact_table,cuboid_table,dimension_col,cuboidid,
METRIC_COLUMN_STRING,CUBOID_METRIC_COLUMNS_STRING,LISTCOLUMNS_STRING,CUBOID_LIST_STRING,DECLARE_STRING_2,CUBOIDLIST_QUERY
);


#### Generating auto cuboid ddl proc and saving into one table 

DYN_QUERY='
INSERT INTO auto_gen_cuboid_dml(proc_name,dml)
SELECT x.proc_name,CONCAT(REPLACE(REPLACE(y.declare_string1,\'auto_gen_cuboid_proc\',x.proc_name),\'auto_gen_cal_tbl\',x.calender_tbl),x.declare_string2,
y.body_string_begin,
';


DML_TEXT='
SELECT attribute FROM (select 
CASE 
WHEN UPPER(TRIM(attribute))=\'DAY\' THEN 1
WHEN UPPER(TRIM(attribute))=\'WEEK\' THEN 2
WHEN UPPER(TRIM(attribute))=\'MONTH\' THEN 3
WHEN UPPER(TRIM(attribute))=\'QUARTER\' THEN 4
WHEN UPPER(TRIM(attribute))=\'SEASON\' THEN 5
WHEN UPPER(TRIM(attribute))=\'YEAR\' THEN 6
END attr_order,X.attribute
from cuboid_metadata X where UPPER(TRIM(dimension))=\'TIME\' ) X ORDER BY attr_order ASC
';

time_loop_query = TO_QUERY(DML_TEXT);
time_loop_array = COLLECT(time_loop_query);

FOR time_loop IN time_loop_array
LOOP

IF UPPER(time_loop.attribute)='DAY'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_day1,x.cuboidlist_query,y.body_string_day2, ');
ELSIF UPPER(time_loop.attribute)='WEEK'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_week1,x.cuboidlist_query,y.body_string_week2, ');
ELSIF UPPER(time_loop.attribute)='MONTH'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_month1,x.cuboidlist_query,y.body_string_month2, ');
ELSIF UPPER(time_loop.attribute)='QUARTER'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_quarter1,x.cuboidlist_query,y.body_string_quarter2, ');
ELSIF UPPER(time_loop.attribute)='SEASON'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_season1,x.cuboidlist_query,y.body_string_season2, ');
ELSIF UPPER(time_loop.attribute)='YEAR'
THEN DYN_QUERY=CONCAT(DYN_QUERY,' y.body_string_year1,x.cuboidlist_query,y.body_string_year2, ');
END IF;

END LOOP;

DYN_QUERY=CONCAT(DYN_QUERY,'
y.body_string_exception) hh
from cs_cuboid_proc_tbl x join cs_cuboid_dml_template_tbl y
where x.proc_type=y.proc_type and x.proc_type ="',procedure_type,'" 
and x.proc_name="',procedure_name,'"
');


EXECUTE IMMEDIATE DYN_QUERY;

EXCEPTION 
WHEN OTHERS THEN

ERR_MSG=exception_message();

RAISE user_exception(ERR_MSG);

end //
delimiter ;

#######
